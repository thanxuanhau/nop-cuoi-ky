﻿#include <iostream>
#include <SDL.h>
#include <SDL_image.h>
#include <vector>
#include <algorithm>
using namespace std;
const int BOARD_SIZE = 3;
const int SCREEN_WIDTH = 600;
const int SCREEN_HEIGHT = 600;
const char* IMAGE = "ayla.png";
const int NUMBER_WIDTH = 200;
const int NUMBER_HEIGHT = 200;
const int CELL_SIZE = SCREEN_WIDTH / BOARD_SIZE;
const int NUM_CELLS = BOARD_SIZE * BOARD_SIZE;
SDL_Texture* loadNumbers(SDL_Renderer* renderer) {
    SDL_Surface* Surface = IMG_Load(IMAGE);
    SDL_Texture* numbersTexture = SDL_CreateTextureFromSurface(renderer, Surface);
    SDL_FreeSurface(Surface);
    return numbersTexture;
}
void drawNumber(SDL_Renderer* renderer, SDL_Texture* numbersTexture, int number, int x, int y) {
    int srcX = (number % 3) * NUMBER_WIDTH;
    int srcY = (number / 3) * NUMBER_HEIGHT;
    SDL_Rect srcRect = { srcX, srcY, NUMBER_WIDTH, NUMBER_HEIGHT };
    SDL_Rect destRect = { x, y, CELL_SIZE, CELL_SIZE };
    SDL_RenderCopy(renderer, numbersTexture, &srcRect, &destRect);
}
vector<int> puzzleState = { 1, 2, 3, 4, 5, 6, 7, 8, 0 };
int emptyCellIndex = NUM_CELLS - 1;
SDL_Window* window = nullptr;
SDL_Renderer* renderer = nullptr;
void moveEmptyCell(int newIndex) {
    swap(puzzleState[emptyCellIndex], puzzleState[newIndex]);
    emptyCellIndex = newIndex;
}
bool initSDL() {
    window = SDL_CreateWindow("Puzzle Game", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN);

    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    return true;
}
void loadGame() {
    random_shuffle(puzzleState.begin(), puzzleState.end());
    emptyCellIndex = find(puzzleState.begin(), puzzleState.end(), 0) - puzzleState.begin();
}
void renderGame(SDL_Texture* numbersTexture) {
    SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
    SDL_RenderClear(renderer);
    for (int i = 0; i < NUM_CELLS; ++i) {
        if (puzzleState[i] != 0) {
            int row = i / BOARD_SIZE;
            int col = i % BOARD_SIZE;

            SDL_Rect cellRect = { col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE };
            SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
            SDL_RenderDrawRect(renderer, &cellRect);

            drawNumber(renderer, numbersTexture, puzzleState[i], col * CELL_SIZE, row * CELL_SIZE);
        }
    }
    SDL_RenderPresent(renderer);
}
void handleEvent(SDL_Event& event) {
    if (event.type == SDL_KEYDOWN) {
        switch (event.key.keysym.sym) {
        case SDLK_a:
            if (emptyCellIndex % BOARD_SIZE > 0) {
                moveEmptyCell(emptyCellIndex - 1);
            }
            break;
        case SDLK_d:
            if (emptyCellIndex % BOARD_SIZE < BOARD_SIZE - 1) {
                moveEmptyCell(emptyCellIndex + 1);
            }
            break;
        case SDLK_w:
            if (emptyCellIndex >= BOARD_SIZE) {
                moveEmptyCell(emptyCellIndex - BOARD_SIZE);
            }
            break;
        case SDLK_s:
            if (emptyCellIndex < NUM_CELLS - BOARD_SIZE) {
                moveEmptyCell(emptyCellIndex + BOARD_SIZE);
            }
            break;
        }
    }
}
bool isGameComplete() {
    for (int i = 0; i < NUM_CELLS - 1; ++i) {
        if (puzzleState[i] != i + 1) {
            return false;
        }
    }
    return true;
}
int main(int argc, char* argv[]) {
    if (!initSDL()) {
        return -1;
    }
    SDL_Texture* numbersTexture = loadNumbers(renderer);
    loadGame();
    bool quit = false;
    bool congratulated = false; 
    SDL_Event e;
    while (!quit) {
        while (SDL_PollEvent(&e) != 0) {
            if (e.type == SDL_QUIT) {
                quit = true;
            }
            handleEvent(e);
        }
        renderGame(numbersTexture);

        if (isGameComplete() && !congratulated) {
            cout << "Chúc mừng bạn đã hoàn thành!" << endl;
            congratulated = true;
        }
    }
    SDL_DestroyTexture(numbersTexture);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
}
